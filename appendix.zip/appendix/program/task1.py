#!/usr/bin/env python
# coding: utf-8

# In[1]:


# -*- coding: utf-8 -*-
import pandas as pd
df=pd.read_csv(r'C:\Users\华硕\Desktop\data1.csv',  encoding='gbk')


# In[2]:


dfA=df[df["地点"].str.contains('A')]
dfA.to_csv(r'C:\Users\华硕\Desktop\task1-1A.csv',  encoding='gbk')


# In[3]:


dfA=df[df["地点"].str.contains('B')]
dfA.to_csv(r'C:\Users\华硕\Desktop\task1-1B.csv',  encoding='gbk')


# In[4]:


dfA=df[df["地点"].str.contains('C')]
dfA.to_csv(r'C:\Users\华硕\Desktop\task1-1C.csv',  encoding='gbk')


# In[5]:


dfA=df[df["地点"].str.contains('D')]
dfA.to_csv(r'C:\Users\华硕\Desktop\task1-1D.csv',  encoding='gbk')


# In[6]:


dfA=df[df["地点"].str.contains('E')]
dfA.to_csv(r'C:\Users\华硕\Desktop\task1-1E.csv',  encoding='gbk')


# In[17]:


#A售货机2017年5月销售额总量与订单量
import  numpy as np
dataa=pd.read_csv(r'C:\Users\华硕\Desktop\task1-1A.csv',  encoding='gbk')
dataa['支付时间'] = pd.to_datetime(dataa['支付时间'])
dataaa= dataa.set_index('支付时间')
suma5=dataaa['2017-5']["实际金额"].sum()
counta5=dataaa['2017-5']["订单号"].count()


# In[8]:


datab=pd.read_csv(r'C:\Users\华硕\Desktop\task1-1B.csv',  encoding='gbk')
datab['支付时间'] = pd.to_datetime(datab['支付时间'])
databb= datab.set_index('支付时间')
sumb5=databb['2017-5']["实际金额"].sum()
countb5=databb['2017-5']["订单号"].count()


# In[9]:


datac=pd.read_csv(r'C:\Users\华硕\Desktop\task1-1C.csv',  encoding='gbk')
datac['支付时间'] = pd.to_datetime(datac['支付时间'])
datacc= datac.set_index('支付时间')
sumc5=datacc['2017-5']["实际金额"].sum()
countc5=datacc['2017-5']["订单号"].count()


# In[10]:


datad=pd.read_csv(r'C:\Users\华硕\Desktop\task1-1D.csv',  encoding='gbk')
datad['支付时间'] = pd.to_datetime(datad['支付时间'])
datadd= datac.set_index('支付时间')
sumd5=datadd['2017-5']["实际金额"].sum()
countd5=datadd['2017-5']["订单号"].count()


# In[11]:


datae=pd.read_csv(r'C:\Users\华硕\Desktop\task1-1E.csv',  encoding='gbk')
datae['支付时间'] = pd.to_datetime(datae['支付时间'])
dataee= datae.set_index('支付时间')
sume5=dataee['2017-5']["实际金额"].sum()
counte5=dataee['2017-5']["订单号"].count()


# In[16]:


#2017年所有售货机销售额之和
sum=df["实际金额"].sum()
count=df["订单号"].count()


# In[20]:


# -*- coding: utf-8 -*-
#A售货机1月每单平均交易额与日均订单量：
import pandas as pd
import  numpy as np
dataa=pd.read_csv(r'C:\Users\华硕\Desktop\task1-1A.csv',  encoding='gbk')
dataa['支付时间'] = pd.to_datetime(dataa['支付时间'])
dataaa= dataa.set_index('支付时间')
suma1=dataaa['2017-1']["实际金额"].sum()
counta1=dataaa['2017-1']["订单号"].count()
average1a1=suma1/counta1
average2a1=counta1/31
#以上以A售货机1月数据为例，其它售货机对写入的文件进行修改，其它月份对月份的数量进行修改即可


# In[ ]:




