#!/usr/bin/env python
# coding: utf-8

# In[5]:


# -*- coding: utf-8 -*-
#将附件一中的“支付时间”转换为时间格式，再对2017年6月的数据以商品为类别，对实际金额进行求和，可以得到每种商品2017年6月销量额度和
import pandas as pd
import  numpy as np
df=pd.read_csv(r'C:\Users\华硕\Desktop\data1.csv',  encoding='gbk')
df['支付时间'] = pd.to_datetime(df['支付时间'])
data= df.set_index('支付时间')
data2=data['2017-6'].groupby("商品")["实际金额"].sum
#在csv中通过降序得出销量前五商品和销售额


# In[6]:


#探究每台售货机每月销售总额，以A售货机1月交易额为例
dataa=pd.read_csv(r'C:\Users\华硕\Desktop\task1-1A.csv',  encoding='gbk')
dataa['支付时间'] = pd.to_datetime(dataa['支付时间'])
dataaa= dataa.set_index('支付时间')
suma1=dataaa['2017-1']["实际金额"].sum()
#其它售货机对写入的文件进行修改，其它月份对月份的数量进行修改即可


# In[8]:


#对A售货机中的商品进行类别匹配（饮料与非饮料），得到task1-1A - 副本.csv
#求得饮料类与非饮料类销售总额，根据不同类别的利润情况计算售货机毛利润，并求出售货机毛利润占比
df=pd.read_csv(r'C:\Users\华硕\Desktop\task1-1A - 副本.csv',  encoding='gbk')
sumA=df.groupby("类别")["实际金额"].sum()


# In[11]:


#探求每月交易额均值，这里以1月为例
#将附件中一月份销售数据提取出来，并根据提取出的数据对商品的实际金额求和，得到1月每种商品的交易额
#再得出每个月交易额均值
dataa=pd.read_csv(r'C:\Users\华硕\Desktop\data1.csv',  encoding='gbk')
dataa['支付时间'] = pd.to_datetime(dataa['支付时间'])
dataaa= dataa.set_index('支付时间')
average1=(dataaa['2017-1'].groupby("商品")["实际金额"].sum())/5
average1.to_csv(r'C:\Users\华硕\Desktop\average1.csv')
#不同月份只需更改提取的数据范围即可


# In[14]:


#前面已经提取过每个月商品销售额数据，对商品进行“二级类”信息匹配后，对二级类商品的1月销售均额进行求和
#得到一月份各个二级类商品的销售额，进一步求得一月份各个二级类商品的销售均额
df=pd.read_csv(r'C:\Users\华硕\Desktop\average11.csv',  encoding='gbk')
sum1=df.groupby("二级类")["1月销售均额"].sum()
sum1.to_csv(r'C:\Users\华硕\Desktop\average12.csv',  encoding='gbk')


# In[ ]:




