#!/usr/bin/env python
# coding: utf-8

# In[2]:


# -*- coding: utf-8 -*-
import pandas as pd
import  numpy as np
#对每台售货机饮料类商品贴上标签
#已提取出来A售货机销售数据，对商品的订单号计数，可求得不同商品的销售额，并以此为数据依据对商品贴上标签
dataa=pd.read_csv(r'C:\Users\华硕\Desktop\task1-1A.csv',  encoding='gbk')
suma=dataa.groupby("商品")["订单号"].count()
suma.to_csv(r'C:\Users\华硕\Desktop\task3-1a.csv',  encoding='gbk')


# In[5]:


#B售货机
datab=pd.read_csv(r'C:\Users\华硕\Desktop\task1-1B.csv',  encoding='gbk')
sumb=datab.groupby("商品")["订单号"].count()
sumb.to_csv(r'C:\Users\华硕\Desktop\task3-1b.csv',  encoding='gbk')


# In[9]:


#C售货机
datac=pd.read_csv(r'C:\Users\华硕\Desktop\task1-1C.csv',  encoding='gbk')
sumc=datac.groupby("商品")["订单号"].count()
sumc.to_csv(r'C:\Users\华硕\Desktop\task3-1c.csv',  encoding='gbk')


# In[ ]:


#D售货机
datad=pd.read_csv(r'C:\Users\华硕\Desktop\task1-1D.csv',  encoding='gbk')
sumd=datad.groupby("商品")["订单号"].count()
sumd.to_csv(r'C:\Users\华硕\Desktop\task3-1d.csv',  encoding='gbk')


# In[ ]:


#E售货机
datae=pd.read_csv(r'C:\Users\华硕\Desktop\task1-1E.csv',  encoding='gbk')
sume=datae.groupby("商品")["订单号"].count()
sume.to_csv(r'C:\Users\华硕\Desktop\task3-1e.csv',  encoding='gbk')

